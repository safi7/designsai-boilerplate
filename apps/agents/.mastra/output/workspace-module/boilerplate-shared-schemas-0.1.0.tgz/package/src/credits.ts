import { z } from 'zod';
import { PageInfoSchema } from './common.js';

/** Credit amounts cross the wire as decimal strings: floats cannot represent the ledger exactly. */
export const CreditAmountSchema = z.string().regex(/^-?\d+(\.\d+)?$/);

export const CreditBalanceResponseSchema = z.object({
  balance: CreditAmountSchema,
  /** Soonest expiry among sources that still hold credits. */
  nextExpiry: z
    .object({ amount: CreditAmountSchema, expiresAt: z.string() })
    .nullable(),
});
export type CreditBalanceResponse = z.infer<typeof CreditBalanceResponseSchema>;

export const CreditTransactionTypeSchema = z.enum(['grant', 'usage', 'refund', 'expiry', 'adjustment']);

export const CreditTransactionSchema = z.object({
  id: z.string(),
  type: CreditTransactionTypeSchema,
  amount: CreditAmountSchema,
  balanceAfter: CreditAmountSchema,
  description: z.string().nullable(),
  referenceType: z.string().nullable(),
  referenceId: z.string().nullable(),
  createdAt: z.string(),
});
export type CreditTransaction = z.infer<typeof CreditTransactionSchema>;

export const CreditTransactionListResponseSchema = z.object({
  items: z.array(CreditTransactionSchema),
  pageInfo: PageInfoSchema,
});
export type CreditTransactionListResponse = z.infer<typeof CreditTransactionListResponseSchema>;

export const CreditPackageSchema = z.object({
  packageId: z.string(),
  name: z.string(),
  credits: z.number().int(),
  price: z.string(),
  currency: z.string(),
  validityDays: z.number().int().nullable(),
});
export type CreditPackage = z.infer<typeof CreditPackageSchema>;

export const CreditPackageListResponseSchema = z.object({
  packages: z.array(CreditPackageSchema),
  checkoutEnabled: z.boolean(),
});
export type CreditPackageListResponse = z.infer<typeof CreditPackageListResponseSchema>;

export const CheckoutRequestSchema = z.object({ packageId: z.string().min(1).max(50) });
export type CheckoutRequest = z.infer<typeof CheckoutRequestSchema>;

export const CheckoutResponseSchema = z.object({ checkoutUrl: z.string().url() });
export type CheckoutResponse = z.infer<typeof CheckoutResponseSchema>;
